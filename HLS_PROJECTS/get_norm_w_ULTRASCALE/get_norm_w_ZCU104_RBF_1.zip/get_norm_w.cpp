#include "get_norm_w.h"

void get_w(data_matrix_stream &data_matrices,
		   sv_coeffs_stream &sv_coeffs,
		   dataset_details_stream &ds_details_in,
		   sv_coeffs_stream &norm_w_out){
#pragma HLS INTERFACE ap_ctrl_none port=return
#pragma HLS INTERFACE axis port=norm_w_out
#pragma HLS INTERFACE axis port=ds_details_in
#pragma HLS INTERFACE axis port=sv_coeffs
#pragma HLS INTERFACE axis port=data_matrices

	// get the no_svs and no_variables from stream
	n_svs no_svs;
	n_variables no_variables;

	// read dataset details stream and store as scalars
	no_svs = ap_uint<20>(ds_details_in.read().data);
	no_variables = ap_uint<9>(ds_details_in.read().data);

	// returns the weights vector and its norm - weights vector w[n] in arguments list (pointer)
	coeffs norm_w = 0;

	coeffs w[n];

	for(loop_ind_n n1 = 0; n1 < n; n1++){
		w[n1] = 0;							// array initialise to zero
	}

	// compute the weights vector, w
	for(loop_ind_m n1 = 0; n1 < m; n1++){
		if(n1 < no_svs){
			//data_vectors coeff_in = sv_coeffs.read().data;
			//coeffs current_coeff = coeff_in.to_float();	// get support vector coefficient
			coeffs current_coeff = sv_coeffs.read().data;

			for(loop_ind_n n2 = 0; n2 < n; n2++){
#pragma HLS PIPELINE
				if(n2 < no_variables){
					// only read the actual array sizes - in PS, pass the correct array size to stream:
					w[n2] = w[n2] + current_coeff * data_matrices.read().data;	// accessed sequentially - in C++, arrays arranged along columns then down rows in memory
				}
				else{
					break;
				}
			}
		}
		else{
			break;
		}
	}

	// compute the norm of w, ||w|| - square norm is computed then square root it
	coeffs square_norm = 0;
	for(loop_ind_n n3 = 0; n3 < n; n3++){
#pragma HLS PIPELINE
		if(n3 < no_variables){
			square_norm = square_norm + w[n3] * w[n3];
		}
		else{
			break;
		}
	}
	norm_w = coeffs(sqrt(square_norm.to_float()));			// use to_float() to convert ap_fixed to float

	sv_coeffs_AXIS norm_w_AXIS;
	norm_w_AXIS.data = norm_w;
	norm_w_AXIS.last = 1;
	norm_w_out.write(norm_w_AXIS);

}
