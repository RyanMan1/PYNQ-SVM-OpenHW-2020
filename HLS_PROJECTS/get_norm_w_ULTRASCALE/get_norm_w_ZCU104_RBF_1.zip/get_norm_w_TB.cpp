#include "get_norm_w.h"
#include <string>

using namespace std;

void get_dataset_details(ds_details dataset_details[3]){
	// return the 3 values relating to the dataset
	// number of variables
	// number of testing vectors
	ifstream data_in;
	data_in.open("C:/Users/Ryan/Documents/University/Project/MATLAB/Test Project/data_files_small/ds_details.dat");
	for(int i = 0; i < 3; i++){
		data_in >> dataset_details[i];
	}
	data_in.close();
}

void get_training_model(data_matrices_AXIS support_vectors[m][n], sv_coeffs_AXIS sv_coeffs[m], int *no_svs, offsets *offsets, int *no_variables, int current_classifier){
// read the support vectors, support vector coefficients, number of support vectors and offset values
	//n_variables no_variables = ds_details[0];
	//n_test_vectors no_test_vectors = ds_details[1];
	//n_classes no_classes = ds_details[2];

	string file_path = "C:/Users/Ryan/Documents/University/Project/MATLAB/Test Project/data_files_small/";
	string svs_file_path = file_path + "svs_" + to_string(current_classifier) + ".dat";
	string coeffs_file_path = file_path + "coeffs_" + to_string(current_classifier) + ".dat";
	string offset_file_path = file_path + "offset_" + to_string(current_classifier) + ".dat";

	ifstream data_svs;
	//data_svs.open("C:/Users/Ryan/Documents/University/Project/MATLAB/Test Project/data_files_small/svs_1.dat");	// support vectors
	data_svs.open(svs_file_path);	// support vectors
	ifstream data_coeffs;
	//data_coeffs.open("C:/Users/Ryan/Documents/University/Project/MATLAB/Test Project/data_files_small/coeffs_1.dat");	// support vector coefficients
	data_coeffs.open(coeffs_file_path);	// support vector coefficients
	ifstream data_offsets;
	//data_offsets.open("C:/Users/Ryan/Documents/University/Project/MATLAB/Test Project/data_files_small/offset_1.dat");	// offsets for each training model
	data_offsets.open(offset_file_path);	// offsets for each training model

	// iterate over the number of support vectors in this class
	for(int j = 0; j < *no_svs; j++){
		// iterate over variables for each support vector
		for(int k1 = 0; k1 < *no_variables; k1++){
			data_svs >> support_vectors[j][k1].data;
			support_vectors[j][k1].last = 0;
		}
		data_coeffs >> sv_coeffs[j].data;
		sv_coeffs[j].last = 0;
	}
	support_vectors[(*no_svs)-1][*no_variables-1].last = 1;	// specify the last element in the data stream
	//sv_coeffs[(*no_svs)-1].last = 1;

	data_offsets >> *offsets;

	data_svs.close();
	data_coeffs.close();
	data_offsets.close();

}

void get_no_svs(n_svs *no_svs, int current_classifier, int no_classes){
	// get number of support vectors for this classifier

	string file_path = "C:/Users/Ryan/Documents/University/Project/MATLAB/Test Project/data_files_small/";
	string n_svs_file_path = file_path + "n_svs.dat";

	ifstream data_no_svs;
	//data_no_svs.open("C:/Users/Ryan/Documents/University/Project/MATLAB/Test Project/data_files_small/n_svs.dat");	// number of support vectors
	data_no_svs.open(n_svs_file_path);	// number of support vectors

	int no_classifiers = no_classes * (no_classes - 1) / 2;
	n_svs no_svs_all[no_classifiers];
	for(int i = 0; i < no_classifiers; i++){
		data_no_svs >> no_svs_all[i];
	}
	//*no_svs = int(no_svs_all[current_classifier - 1]);
	*no_svs = no_svs_all[current_classifier - 1];

	data_no_svs.close();
}

int main(void){

	// CHOOSE THE CLASSIFIER
	int current_classifier = 5;

	// READ IN DETAILS FOR THE DATASET
	ds_details dataset_details[3] = {0};
	get_dataset_details(dataset_details);
	n_variables no_variables = dataset_details[0];
	int no_test_vectors = dataset_details[1];
	int no_classes = dataset_details[2];

	int no_variables_int = no_variables.to_int();
	int no_test_vectors_int = no_test_vectors;

	// READ IN DETAILS FOR THE TRAINING MODEL
	sv_coeffs_AXIS sv_coeffs[m] = {0};
	n_svs no_svs = 0;
	offsets offset = 0;

	// GET NUMBER OF SUPPORT VECTORS FOR THIS CLASSIFIER
	get_no_svs(&no_svs, current_classifier, no_classes);

	int no_svs_int = no_svs.to_int();

	static data_matrices_AXIS support_vectors[m][n];
	get_training_model(support_vectors, sv_coeffs, &no_svs_int, &offset, &no_variables_int, current_classifier);

	// INPUT STREAMS
	sv_coeffs_stream sv_coeffs_in;
	data_matrix_stream data_matrices_in;

	// fill support vectors stream buffer
	for(int i = 0; i < no_svs; i++){
		for(int j = 0; j < no_variables; j++){
			//support_vectors_in.write(support_vectors[i][j]);
			data_matrices_in.write(support_vectors[i][j]);
		}
	}

	// fil support vector coefficients buffer
	for(int i = 0; i < no_svs; i++){
		sv_coeffs_in.write(sv_coeffs[i]);
	}

	// fill dataset details stream
	dataset_details_stream dataset_details_in;
	dataset_details_AXIS no_svs_AXIS;
	dataset_details_AXIS no_variables_AXIS;

	no_svs_AXIS.data = no_svs;
	no_svs_AXIS.last = 0;
	no_variables_AXIS.data = dataset_details[0];
	no_variables_AXIS.last = 1;

	dataset_details_in.write(no_svs_AXIS);
	dataset_details_in.write(no_variables_AXIS);

	// output stream
	sv_coeffs_stream norm_w_stream;

	get_w(data_matrices_in, sv_coeffs_in, dataset_details_in, norm_w_stream);

	cout << "||w|| = " << norm_w_stream.read().data << "\n";
	return 0;	// not self-checking
}
