#include "geometric_values.h"
#include <string>

using namespace std;

void get_dataset_details(float dataset_details[4]){
	// return the 3 values relating to the dataset
	// number of variables
	// number of testing vectors
	ifstream data_in;
	data_in.open("C:/Users/Ryan/Documents/University/Project/MATLAB/Test Project/deployment_files_RBF/ds_details_RBF.dat");
	for(int i = 0; i < 4; i++){
		data_in >> dataset_details[i];
	}
	data_in.close();
}

void get_training_model(data_matrices_AXIS support_vectors[m][n], sv_coeffs_AXIS sv_coeffs[m], int *no_svs, offsets *offsets, int *no_variables, int current_classifier){
// read the support vectors, support vector coefficients, number of support vectors and offset values
	//n_variables no_variables = ds_details[0];
	//n_test_vectors no_test_vectors = ds_details[1];
	//n_classes no_classes = ds_details[2];

	string file_path = "C:/Users/Ryan/Documents/University/Project/MATLAB/Test Project/deployment_files_RBF/";
	string svs_file_path = file_path + "svs_" + to_string(current_classifier) + ".dat";
	string coeffs_file_path = file_path + "coeffs_" + to_string(current_classifier) + ".dat";
	string offset_file_path = file_path + "offset_" + to_string(current_classifier) + ".dat";

	ifstream data_svs;
	//data_svs.open("C:/Users/Ryan/Documents/University/Project/MATLAB/Test Project/data_files_small/svs_1.dat");	// support vectors
	data_svs.open(svs_file_path);	// support vectors
	ifstream data_coeffs;
	//data_coeffs.open("C:/Users/Ryan/Documents/University/Project/MATLAB/Test Project/data_files_small/coeffs_1.dat");	// support vector coefficients
	data_coeffs.open(coeffs_file_path);	// support vector coefficients
	ifstream data_offsets;
	//data_offsets.open("C:/Users/Ryan/Documents/University/Project/MATLAB/Test Project/data_files_small/offset_1.dat");	// offsets for each training model
	data_offsets.open(offset_file_path);	// offsets for each training model

	// iterate over the number of support vectors in this class
	for(int j = 0; j < *no_svs; j++){
		// iterate over variables for each support vector
		for(int k1 = 0; k1 < *no_variables; k1++){
			data_svs >> support_vectors[j][k1].data;
			support_vectors[j][k1].last = 0;
		}
		data_coeffs >> sv_coeffs[j].data;
		sv_coeffs[j].last = 0;
	}
	support_vectors[(*no_svs)-1][*no_variables-1].last = 1;	// specify the last element in the data stream
	//sv_coeffs[(*no_svs)-1].last = 1;

	data_offsets >> *offsets;

	data_svs.close();
	data_coeffs.close();
	data_offsets.close();

}

void read_test_matrix(data_matrices_AXIS testing_matrix[t_max][n], data_labels testing_labels[t_max], data_labels testing_predictions_libsvm[t_max], int no_test_vectors, int no_variables){
	// read from dat file and populate C++ variables
	ifstream data_matrix;
	data_matrix.open("C:/Users/Ryan/Documents/University/Project/MATLAB/Test Project/deployment_files_RBF/test_matrix.dat");
	ifstream labels_data;
	labels_data.open("C:/Users/Ryan/Documents/University/Project/MATLAB/Test Project/deployment_files_RBF/test_labels.dat");
	ifstream predictions_data;
	predictions_data.open("C:/Users/Ryan/Documents/University/Project/MATLAB/Test Project/deployment_files_RBF/test_predictions_libsvm.dat");

	float test = 0.0;
	for(int i = 0; i < no_test_vectors; i++){
		for(int j = 0; j < no_variables; j++){
			data_matrix >> testing_matrix[i][j].data;
			testing_matrix[i][j].last = 0;
		}
		float test_label = 0.0;
		labels_data >> test_label;
		testing_labels[i] = data_labels(test_label);
		float test_prediction = 0.0;
		predictions_data >> test_prediction;
		testing_predictions_libsvm[i] = data_labels(test_prediction);
	}
	testing_matrix[no_test_vectors-1][no_variables-1].last = 1;			// specofy the last elemtn in the data stream
	data_matrix.close();
	labels_data.close();
	predictions_data.close();
}

void get_geometric_values(inter_values geometric_values_actual[t_max], int no_test_vectors, int current_classifier){

	string ge_values_filename = "C:/Users/Ryan/Documents/University/Project/MATLAB/Test Project/deployment_files_RBF/geometric_values_" + to_string(current_classifier) + ".dat";

	ifstream ge_values_data;
	//ge_values_data.open("C:/Users/Ryan/Documents/University/Project/MATLAB/Test Project/data_files_small/geometric_values_1.dat");
	ge_values_data.open(ge_values_filename);

	for(int i = 0; i < no_test_vectors; i++){
		ge_values_data >> geometric_values_actual[i];
	}

	ge_values_data.close();
}

void get_no_svs(n_svs *no_svs, int current_classifier, int no_classes){
	// get number of support vectors for this classifier

	string file_path = "C:/Users/Ryan/Documents/University/Project/MATLAB/Test Project/deployment_files_RBF/";
	string n_svs_file_path = file_path + "n_svs.dat";

	ifstream data_no_svs;
	//data_no_svs.open("C:/Users/Ryan/Documents/University/Project/MATLAB/Test Project/data_files_small/n_svs.dat");	// number of support vectors
	data_no_svs.open(n_svs_file_path);	// number of support vectors

	int no_classifiers = no_classes * (no_classes - 1) / 2;
	n_svs no_svs_all[no_classifiers];
	for(int i = 0; i < no_classifiers; i++){
		data_no_svs >> no_svs_all[i];
	}
	//*no_svs = int(no_svs_all[current_classifier - 1]);
	*no_svs = no_svs_all[current_classifier - 1];

	data_no_svs.close();
}

coeffs get_norm_w(data_matrices_AXIS support_vectors[m][n],
				  sv_coeffs_AXIS sv_coeffs[m],
				  n_svs current_no_svs,
				  n_variables no_variables){
			 	  // returns the weights vector and its norm

	coeffs norm_w = 0;

	coeffs w[n];

	for(int i = 0; i < n; i++){
		w[i] = 0;
	}

	// compute the weights vector, w
	for(int n1 = 0; n1 < current_no_svs; n1++){
		for(int n2 = 0; n2 < no_variables; n2++){
			w[n2] = w[n2] + sv_coeffs[n1].data * support_vectors[n1][n2].data;
		}
	}

	// compute the norm of w, ||w|| - square norm is computed then square root it
	coeffs square_norm = 0;
	for(int n3 = 0; n3 < no_variables; n3++){
		square_norm = square_norm + w[n3] * w[n3];
	}

	norm_w = coeffs(sqrt(square_norm.to_float()));

	return norm_w;

}

// for random tests...
int main_(void){
	/*coeffs square_norm = 56.7843454;
	coeffs out_test;
	out_test = coeffs(sqrt(square_norm.to_float()));
	cout << out_test;*/

	/*data_vectors test1 = 0.7657734;
	coeffs test2 = 14.767655;

	cout << test1 * test2;*/
	return 0;
}

int main(void){

	// CHOOSE THE CLASSIFIER
	int current_classifier = 6;

	// READ IN DETAILS FOR THE DATASET
	float dataset_details[4] = {0};
	get_dataset_details(dataset_details);
	n_variables no_variables = n_variables(dataset_details[0]);
	n_test_vectors no_test_vectors = n_test_vectors(dataset_details[1]);
	n_classes no_classes = n_classes(dataset_details[2]);
	coeffs gamma = dataset_details[3];

	int no_variables_int = no_variables.to_int();
	int no_test_vectors_int = no_test_vectors.to_int();

	// READ IN DETAILS FOR THE TRAINING MODEL
	sv_coeffs_AXIS sv_coeffs[m] = {0};
	n_svs no_svs = 0;
	offsets offset = 0;

	// GET NUMBER OF SUPPORT VECTORS FOR THIS CLASSIFIER
	get_no_svs(&no_svs, current_classifier, no_classes);

	int no_svs_int = no_svs.to_int();

	static data_matrices_AXIS support_vectors[m][n];
	get_training_model(support_vectors, sv_coeffs, &no_svs_int, &offset, &no_variables_int, current_classifier);

	// READ IN TEST MATRIX AND ASSOCIATED LABELS
	data_matrices_AXIS testing_matrix[t_max][n] = {0};
	data_labels testing_labels[t_max] = {0};
	data_labels testing_predictions_libsvm[t_max] = {0};
	read_test_matrix(testing_matrix, testing_labels, testing_predictions_libsvm, no_test_vectors_int, no_variables_int);

	// GET ACTUAL GEOMETRIC VALUES FOR COMPARISON
	inter_values geometric_values_actual[no_test_vectors_int] = {0};
	get_geometric_values(geometric_values_actual, no_test_vectors_int, current_classifier);

	// CREATE CONTIGUOS MEMORY TO PASS TO TOP LEVEL FUNCTION AS DATA STREAM
	//support_vectors_stream support_vectors_in;
	sv_coeffs_stream sv_coeffs_in;
	//testing_matrix_stream testing_matrix_in;
	geometric_values_stream geometric_values_out;
	data_matrix_stream support_vectors_in;

	// make "no_test_vectors" copies of support vectors in stream
	for(int h = 0; h < no_test_vectors_int; h++){
		// fill support vectors stream buffer
		for(int i = 0; i < no_svs; i++){
			for(int j = 0; j < no_variables; j++){
				//support_vectors_in.write(support_vectors[i][j]);
				support_vectors_in.write(support_vectors[i][j]);
			}
		}
	}

	// fil support vector coefficients buffer
	// gamma is first element, norm_w seconf
	sv_coeffs_AXIS gamma_AXIS;
	gamma_AXIS.data = gamma;
	gamma_AXIS.last = 0;
	sv_coeffs_in.write(gamma_AXIS);

	sv_coeffs_AXIS norm_w_AXIS;
	coeffs norm_w;
	norm_w = get_norm_w(support_vectors, sv_coeffs, no_svs, no_variables);
	norm_w_AXIS.data = norm_w;
	norm_w_AXIS.last = 0;
	sv_coeffs_in.write(norm_w_AXIS);

	cout << "\n\nnorm_w: " << norm_w << "\n\n";

	// as with support vectors - need to extend the stream by no_test_vectors - include offset at end of each!
	for(int h = 0; h < no_test_vectors_int; h++){
		for(int i = 0; i < no_svs; i++){
			sv_coeffs_in.write(sv_coeffs[i]);
		}
		// append the offset to end of sv coeffs stream
		sv_coeffs_AXIS offset_AXIS;
		offset_AXIS.data = offset;
		offset_AXIS.last = 1;
		sv_coeffs_in.write(offset_AXIS);
	}


	// get a testing vector
	/*data_matrices_AXIS testing_vector[n];
	data_matrix_stream testing_vector_in;

	for(int i = 0; i < no_variables; i++){
		testing_vector[i].data = testing_matrix[ge_value_index][i].data;
		testing_vector_in.write(testing_vector[i]);
	}*/

	data_matrix_stream testing_matrix_in;
	// stream testing matrix - ********ONLY FIRST TESTING VECTOR USED FOR THIS SIMULATION********
	for(int i = 0; i < no_test_vectors_int; i++){
		for(int j = 0; j < no_variables_int; j++){
			//testing_matrix_in.write(testing_matrix[i][j]);
			testing_matrix_in.write(testing_matrix[i][j]);
		}
	}


	// fill dataset details stream
	dataset_details_stream dataset_details_in;
	dataset_details_AXIS no_svs_AXIS;
	dataset_details_AXIS no_variables_AXIS;
	dataset_details_AXIS no_test_vectors_AXIS;

	no_svs_AXIS.data = no_svs;
	no_svs_AXIS.last = 0;
	no_variables_AXIS.data = dataset_details[0];
	no_variables_AXIS.last = 0;
	no_test_vectors_AXIS.data = no_test_vectors;
	no_test_vectors_AXIS.last = 1;

	dataset_details_in.write(no_svs_AXIS);
	dataset_details_in.write(no_variables_AXIS);
	dataset_details_in.write(no_test_vectors_AXIS);

	// ^^ FOR HLS STREAM/AXIS ^^

	// CALL TOP LEVEL FUNCTION - GET GEOMETRIC VALUES
	//geometric_values_top(support_vectors_in, sv_coeffs_in, &no_svs, &offset, &no_variables, testing_matrix_in, &no_test_vectors, geometric_values_out);
	//geometric_values_top(support_vectors_in, sv_coeffs_in, no_svs, offset, no_variables, testing_matrix_in, no_test_vectors, geometric_values_out);
	geometric_values_rbf_top(support_vectors_in, sv_coeffs_in, testing_matrix_in, dataset_details_in, geometric_values_out);

	// PRINT GEOMETRIC VALUES AND COMPUTE ACCURACY
	cout << "\nGEOMETRIC VALUES \t\tACTUAL GEOMETRIC VALUES\n";
	cout << "--------------------------\n";
	int error_count = 0;
	typedef ap_fixed<32,1> tb_tol;
	tb_tol tolerance = 0.001;
	//float tolerance = 0.001;

	for(int i = 0; i < no_test_vectors; i++){
		inter_values geometric_value = geometric_values_out.read().data;

		cout << geometric_value << "\t\t" << geometric_values_actual[i] << "\n";
		if(((geometric_value < geometric_values_actual[i])
			&& (geometric_value + tolerance) < geometric_values_actual[i])
			|| ((geometric_value > geometric_values_actual[i])
			&& (geometric_value - tolerance) > geometric_values_actual[i])){
				error_count++;
		}
	}

	cout << "\nNUMBER OF ERRORS: " << error_count << "\n";

	// OUTPUT ZERO IF RESULT IS CORRECT - ONE OTHERWISE (WILL FAIL COSIM)
	if(error_count == 0){
		return 0;
	}
	else{
		return 1;
	}
}
