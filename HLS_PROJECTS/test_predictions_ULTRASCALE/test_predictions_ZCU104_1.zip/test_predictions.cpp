#include "test_predictions.h"

void test_predictions(geometric_values_stream &geometric_values,
					  n_classes *no_classes,
					  n_test_vectors *no_test_vectors,
					  test_predictions_stream &test_predictions_out){

	// loop over the testing vectors
	test_predict_outer_loop: for(loop_ind_t n1 = 0; n1 < t_max; n1++){
		if(n1 < *no_test_vectors){

			// initialise class instances:
			data_labels class_instances[k];
			for(loop_ind_c n2_1 = 0; n2_1 < k; n2_1++){
				class_instances[n2_1] = 0;
			}
			//data_labels class_instances[k] = {0};	// maximum number of classes is 255
			ap_uint<15> current_classifier = 1;	// keep track of classifier

			// loop over the classifiers - n2 is positive class, n3 is negative class
			for(loop_ind_c n2 = 0; n2 < (k-1); n2++){
				if(n2 < *no_classes){
					test_predict_inner_loop: for(loop_ind_c n3 = 0; n3 < k; n3++){
#pragma HLS PIPELINE
						if((n3 < *no_classes) && (n3 > n2)){
							// if geometric value positive for that classifier, positive class chosen - else negative class chosen
							if(geometric_values.read().data >= 0.0){
								class_instances[n2] = class_instances[n2] + 1;
							}
							else{
								class_instances[n3] = class_instances[n3] + 1;
							}
							current_classifier++;
						}
					}
				}
				else{
					break;
				}
			}

			// check for maximum value in class_instances - this location corresponds to chosen class for the testing vector
			data_labels current_prediction = 1;
			data_labels current_max_instances = class_instances[0];
			prediction_loop: for(loop_ind_c n2 = 1; n2 < (k+1); n2++){
#pragma HLS PIPELINE
				if(class_instances[n2] > current_max_instances){
					current_prediction = n2 + 1;
					current_max_instances = class_instances[n2];
				}
			}

			// declare struct instance for axi stream with TLAST sideband signal
			test_predictions_AXIS test_prediction;
			test_prediction.data = current_prediction;

			// check are we at end of stream
			if(n1 < (*no_test_vectors - 1)){
				test_prediction.last = 0;
			}
			else{
				test_prediction.last = 1;
			}

			// send output to stream
			test_predictions_out.write(test_prediction);
		}
	}

}

void test_predictions_top(geometric_values_stream &geometric_values,
		  	  	  	  	  dataset_details_stream &dataset_details,
						  test_predictions_stream &test_predictions_out){
#pragma HLS INTERFACE axis port=dataset_details
#pragma HLS INTERFACE axis port=test_predictions_out
#pragma HLS INTERFACE axis port=geometric_values
#pragma HLS INTERFACE ap_ctrl_none port=return

	// dataset details is no_classes -> no_test_vectors

	n_classes no_classes;
	n_test_vectors no_test_vectors;

	no_classes = ap_uint<8>(dataset_details.read().data);
	no_test_vectors = ap_uint<20>(dataset_details.read().data);

	// this function uses the computed geometric values and returns a 2D array of predictions
	// the class label is for each testing vector from [1,k(k-1)/2]
	test_predictions(geometric_values, &no_classes, &no_test_vectors, test_predictions_out);

}
