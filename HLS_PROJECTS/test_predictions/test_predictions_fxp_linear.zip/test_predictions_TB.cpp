#include "test_predictions.h"

using namespace std;

void get_dataset_details(inter_values dataset_details[3]){
	// return the 3 values relating to the dataset
	// number of variables
	// number of classes
	// number of testing vectors
	ifstream data_in;
	data_in.open("C:/Users/Ryan/Documents/University/Project/MATLAB/Test Project/data_files_small/ds_details.dat");
	for(int i = 0; i < 3; i++){
		data_in >> dataset_details[i];
	}
	data_in.close();
}

void read_test_predictions(data_labels testing_predictions_libsvm[t_max], n_test_vectors no_test_vectors){
	// read from dat file and populate C++ variables
	ifstream predictions_data;
	predictions_data.open("C:/Users/Ryan/Documents/University/Project/MATLAB/Test Project/data_files_small/test_predictions_libsvm.dat");

	for(int i = 0; i < no_test_vectors; i++){
		float test_prediction = 0.0;
		predictions_data >> test_prediction;
		testing_predictions_libsvm[i] = data_labels(test_prediction);
	}
	predictions_data.close();
}

void read_geometric_values(geometric_values_stream &geometric_values_in, n_classes no_classes, n_test_vectors no_test_vectors){
	int no_classes_int = no_classes.to_int();
	int no_test_vectors_int = no_test_vectors.to_int();

	int no_classifiers = no_classes * (no_classes - 1) / 2;

	geometric_values_AXIS geometric_values[no_test_vectors_int][no_classifiers];

	for(int i = 0; i < no_classifiers; i++){
		ifstream geo_values_data;
		std::string file_path = "C:/Users/Ryan/Documents/University/Project/MATLAB/Test Project/data_files_small/";
		std::string file_ext = ".dat";
		std::string filename = file_path + "geometric_values_" + to_string(i+1) + file_ext;
		geo_values_data.open(filename);
		for(int j = 0; j < no_test_vectors_int; j++){
			geo_values_data >> geometric_values[j][i].data;
			geometric_values[j][i].last = 0;
		}
	}

	// indicate last elemtn in stream
	geometric_values[no_test_vectors_int - 1][no_classifiers - 1].last = 1;

	for(int i = 0; i < no_test_vectors_int; i++){
		for(int j = 0; j < no_classifiers; j++){
			geometric_values_in.write(geometric_values[i][j]);
		}
	}

}

int main(){
	// READ IN DETAILS FOR THE DATASET
	inter_values dataset_details[3];
	get_dataset_details(dataset_details);
	n_classes no_test_vectors = dataset_details[1];
	n_test_vectors no_classes = dataset_details[2];

	data_labels test_predictions_actual[t_max];

	read_test_predictions(test_predictions_actual, no_test_vectors);

	//geometric_values_AXIS geometric_values[t_max][max_classifiers];
	geometric_values_stream geometric_values_in;

	read_geometric_values(geometric_values_in, no_classes, no_test_vectors);

	test_predictions_stream test_predictions_out;

	// generate stream for dataset details
	dataset_details_stream dataset_details_in;

	dataset_details_AXIS ds_details_AXIS;
	ds_details_AXIS.data = no_classes;
	ds_details_AXIS.last = 0;

	dataset_details_in.write(ds_details_AXIS);

	ds_details_AXIS.data = no_test_vectors;
	ds_details_AXIS.last = 1;

	dataset_details_in.write(ds_details_AXIS);

	// call top-level funtcion
	test_predictions_top(geometric_values_in, dataset_details_in, test_predictions_out);

	int error_count = 0;

	data_labels test_prediction;
	// print test predictions to console
	for(int i = 0; i < no_test_vectors; i++){
		test_prediction = test_predictions_out.read().data;
		cout << test_prediction << "\n";
		if(test_prediction != test_predictions_actual[i]){
			error_count++;
		}
	}

	if(error_count > 0){
		return 1;
	}
	else{
		return 0;			// pass cosim
	}
}
