#include "geometric_values.h"

using namespace std;

coeffs get_w(data_matrix_stream &data_matrices,
		 	 sv_coeffs_stream &sv_coeffs,
			 n_svs *no_svs,
			 n_variables *no_variables,
			 coeffs w[n]){

	// returns the weights vector and its norm - weights vector w[n] in arguments list (pointer)
	coeffs norm_w = 0;

	for(loop_ind_n n1 = 0; n1 < n; n1++){
		w[n1] = 0;							// array initialise to zero
	}

	// compute the weights vector, w
	for(loop_ind_m n1 = 0; n1 < m; n1++){
		if(n1 < *no_svs){
			//data_vectors coeff_in = sv_coeffs.read().data;
			//coeffs current_coeff = coeff_in.to_float();	// get support vector coefficient
			coeffs current_coeff = sv_coeffs.read().data;

			for(loop_ind_n n2 = 0; n2 < n; n2++){
#pragma HLS PIPELINE
				if(n2 < *no_variables){
					// only read the actual array sizes - in PS, pass the correct array size to stream:
					w[n2] = w[n2] + current_coeff * data_matrices.read().data;	// accessed sequentially - in C++, arrays arranged along columns then down rows in memory
				}
				//else{
				//	break;
				//}
			}
		}
		else{
			break;
		}
	}

	// compute the norm of w, ||w|| - square norm is computed then square root it
	coeffs square_norm = 0;
	for(loop_ind_n n3 = 0; n3 < n; n3++){
#pragma HLS PIPELINE
		if(n3 < *no_variables){
			square_norm = square_norm + w[n3] * w[n3];
		}
	}
	norm_w = coeffs(sqrt(square_norm.to_float()));			// use to_float() to convert ap_fixed to float

	return norm_w;
}

void get_geometric_values_linear(data_matrix_stream &data_matrices,
								 sv_coeffs_stream &sv_coeffs,
								 n_svs *no_svs,
								 n_variables *no_variables,
								 n_test_vectors *no_test_vectors,
								 geometric_values_stream &geometric_values){

	// this function performs the same operation as the kernelised version - by computing the matrix
	// of geometric values - it is optimised for the linear kernel in that w is explicitly calculated

	// weights vector
	coeffs norm_w = 0;

	// compute w and ||w||
	coeffs w[n];
	norm_w = get_w(data_matrices, sv_coeffs, no_svs, no_variables, w);

	coeffs one = 1;
	coeffs norm_w_recip = one / norm_w;				// so we do not have to compute this division in every iteration of geometric values

	//coeffs norm_w_recip = norm_w_reciprocal(norm_w);

	coeffs offset = sv_coeffs.read().data;		// final element of sv coeffs stream is the offset

	coeffs f_value = 0;
	geometric_values_AXIS geometric_value;

	// iterate over all test vectors for this classifier to obtain geometric values
	geo_vals_outer_loop: for(loop_ind_t n1 = 0; n1 < t_max; n1++){
		if(n1 < *no_test_vectors){

			f_value = 0;	// functional value for testing vector at n2 with classifier n1 - can be negative or positive

			// compute the functional value using the dot product of the test vector with w for this binary classifier
			get_f_value_loop: for(loop_ind_n n2 = 0; n2 < n; n2++){
#pragma HLS PIPELINE
				if(n2 < *no_variables){
					//data_vectors tm_in = testing_matrix.read().data;
					//f_value += w[n2] * tm_in.to_float();		// testing matrix accessed sequentially
					//f_value += w[n2] * testing_matrix.read().data.to_float();
					//f_value = update_f_value(f_value, w, testing_matrix, n2);

					f_value = f_value + w[n2] * data_matrices.read().data;

				}
			}

			//f_value = f_value_mac(w, testing_matrix, no_variables);

			// compute the geometric values by adding the offset and scaling the functional values by the norm of the weights vector
			coeffs temp_var = f_value + offset;
			geometric_value.data = temp_var * norm_w_recip;

			//geometric_value.data = (f_value + offset) * norm_w_recip;

			//geometric_value.data = (f_value + offset) * norm_w_recip;
			//coeffs geo_value_temp = (f_value + offset) / norm_w;
			//geometric_value.data = float(geo_value_temp);

			// check if we are at the end of the stream:
			if(n1 == (*no_test_vectors - 1)){
				geometric_value.last = 1;
			}
			else{
				geometric_value.last = 0;
			}

			// write geometric value to stream:
			geometric_values.write(geometric_value);
		}
		else{
			break;
		}
	}
}

void geometric_values_top(data_matrix_stream &data_matrices,
		  	  	  	  	  sv_coeffs_stream &sv_coeffs,
						  dataset_details_stream &dataset_details,
						  geometric_values_stream &geometric_values){
#pragma HLS INTERFACE axis port=data_matrices
#pragma HLS INTERFACE axis port=dataset_details
#pragma HLS INTERFACE axis port=geometric_values
#pragma HLS INTERFACE axis port=sv_coeffs
#pragma HLS INTERFACE ap_ctrl_none port=return

	// Note, the offset is the last element in the sv coeffs stream
	// Note, data_matrices contains the support vectors and testing matrix

	// dataset_details stream => no_svs -> no_variables -> no_test_vectors

	// PYNQ MMIO requires top-level scalar arguments to be pointers otherwise unexpected behaviour

	//ds_details no_svs;
	//ds_details no_variables;
	//ds_details no_test_vectors;

	n_svs no_svs;
	n_variables no_variables;
	n_test_vectors no_test_vectors;

	// read dataset details stream and store as scalars
	no_svs = dataset_details.read().data;
	no_variables = ap_uint<9>(dataset_details.read().data);
	no_test_vectors = dataset_details.read().data;

	// call function to compute geometric values using the default linear kernel
	get_geometric_values_linear(data_matrices,
			   	   	   	  sv_coeffs,
						  &no_svs,
						  &no_variables,
						  &no_test_vectors,
						  geometric_values);

}
