#include "hls_design_meta.h"
const Port_Property HLS_Design_Meta::port_props[]={
	Port_Property("ap_clk", 1, hls_in, -1, "", "", 1),
	Port_Property("ap_rst_n", 1, hls_in, -1, "", "", 1),
	Port_Property("data_matrices_TDATA", 16, hls_in, 0, "axis", "in_data", 1),
	Port_Property("data_matrices_TVALID", 1, hls_in, 1, "axis", "in_vld", 1),
	Port_Property("data_matrices_TREADY", 1, hls_out, 1, "axis", "in_acc", 1),
	Port_Property("data_matrices_TLAST", 1, hls_in, 1, "axis", "in_data", 1),
	Port_Property("sv_coeffs_TDATA", 32, hls_in, 2, "axis", "in_data", 1),
	Port_Property("sv_coeffs_TVALID", 1, hls_in, 3, "axis", "in_vld", 1),
	Port_Property("sv_coeffs_TREADY", 1, hls_out, 3, "axis", "in_acc", 1),
	Port_Property("sv_coeffs_TLAST", 1, hls_in, 3, "axis", "in_data", 1),
	Port_Property("dataset_details_TDATA", 32, hls_in, 4, "axis", "in_data", 1),
	Port_Property("dataset_details_TVALID", 1, hls_in, 5, "axis", "in_vld", 1),
	Port_Property("dataset_details_TREADY", 1, hls_out, 5, "axis", "in_acc", 1),
	Port_Property("dataset_details_TLAST", 1, hls_in, 5, "axis", "in_data", 1),
	Port_Property("geometric_values_TDATA", 32, hls_out, 6, "axis", "out_data", 1),
	Port_Property("geometric_values_TVALID", 1, hls_out, 7, "axis", "out_vld", 1),
	Port_Property("geometric_values_TREADY", 1, hls_in, 7, "axis", "out_acc", 1),
	Port_Property("geometric_values_TLAST", 1, hls_out, 7, "axis", "out_data", 1),
};
const char* HLS_Design_Meta::dut_name = "geometric_values_top";
