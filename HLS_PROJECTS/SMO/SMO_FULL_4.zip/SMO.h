#ifndef SMO_H__
#define SMO_H__

#include <cmath>
#include <math.h>
#include <ap_fixed.h>
#include <ap_int.h>

#include "hls_stream.h"
#include <ap_axi_sdata.h>

#define m 20000	// maximum number of possible training vectors in the dataset
#define n 256		// maximum number of possible variables in the dataset
#define max_itr_abs 100 // absolute maximum number of iterations

//typedef float data_vectors;
typedef ap_fixed<16,1> data_vectors;	// 1 bit for integer component - only work for hs datasets

//typedef float dot_products;
typedef ap_fixed<32,12> dot_products;

//typedef int class_labels;
typedef ap_int<2> class_labels;			// only stores values of -1 and 1 - two bits signed integer required

//typedef int training_data_indices;
typedef ap_uint<16> training_data_indices;	// maximum of 65535 training vectors

//typedef int n_training_vectors;
typedef ap_uint<16> n_training_vectors;		// maximum of 65535 training vectors (per binary classifier)

//typedef int n_variables;
//typedef int n_variables;
typedef ap_uint<9> n_variables;				// max 256 variables

typedef ap_uint<8> n_max_itr;					// max 255 iteration

//typedef float training_details;
typedef ap_fixed<32,12> training_details;	// 12 bits for integer component - max value of C and offset is 4095

//typedef float inter_values;
typedef ap_fixed<32,12> inter_values;

//typedef float alphas;
typedef ap_fixed<32,12> alphas;

//typedef int loop_ind;
typedef ap_uint<16> loop_ind_m;			// loop over training vectors
typedef ap_uint<9> loop_ind_n;			// loop over variables - only increment from zero to 255
typedef ap_uint<8> loop_ind_itr;

// structs contain the sideband signal TLAST which must be set when the stream has completed
struct dot_product_matrix_AXIS{
	dot_products data;
	bool last;
};

struct training_labels_AXIS{
	ap_int<8> data;
	bool last;
};

struct training_matrix_AXIS{
	data_vectors data;
	bool last;
};

struct scalars_AXIS{
	training_details data;
	bool last;
};

struct input_details_AXIS{
	float data;
	bool last;
};
// this needs to contain floats => no_training_vectors -> no_variables -> C -> tolerance -> offset -> Ep -> p
// this contains offset -> changed_alphas for output

struct alphas_AXIS{
	alphas data;
	bool last;
};

struct indicators_AXIS{
	ap_uint<8> data;
	bool last;
};

// HLS stream types
typedef hls::stream<dot_product_matrix_AXIS> dot_product_matrix_stream;
typedef hls::stream<training_labels_AXIS> training_labels_stream;
typedef hls::stream<training_matrix_AXIS> training_matrix_stream;
typedef hls::stream<scalars_AXIS> scalars_stream;
typedef hls::stream<alphas_AXIS> alphas_stream;
typedef hls::stream<scalars_AXIS> offset_stream;
typedef hls::stream<indicators_AXIS> indicators_stream;
typedef hls::stream<input_details_AXIS> input_details_stream;


dot_products dot_product(data_vectors row_vec[n], data_vectors col_vec[n], n_variables *no_variables);

void get_training_vector(training_matrix_stream &training_matrix,
						 data_vectors x_q,
						 n_variables *no_variables);

inter_values get_u_k(dot_product_matrix_stream &dot_product_matrix,
		   	 	 	 class_labels y[m],
					 alphas_AXIS alpha[m],
					 n_training_vectors *no_training_vectors,
					 n_variables *no_variables,
					 training_details *offset);

void SMO_p_loop_linear(dot_product_matrix_stream &dot_product_matrix,
					   training_matrix_stream &training_matrix,
					   data_vectors x_p[n],
					   class_labels y[m],
					   alphas_AXIS alpha[m],
					   n_training_vectors *no_training_vectors,
					   n_variables *no_variables,
					   training_details *C,
					   training_details *tolerance,
					   training_details *offset,
					   inter_values *E_p,
					   training_data_indices *p_in,
					   n_training_vectors *changed_alphas);

void SMO_outer(dot_product_matrix_stream &dot_product_matrix_outer,
		 	   dot_product_matrix_stream &dot_product_matrices_inner,
			   class_labels y[m],
			   training_matrix_stream &training_matrix_outer,
			   training_matrix_stream &training_matrices_inner,
			   alphas_AXIS alpha[m],
			   n_training_vectors *no_training_vectors,
			   n_variables *no_variables,
			   training_details *C,
			   training_details *tolerance,
			   n_max_itr *max_itr_user,
			   indicators_stream &kkt_violations,
			   scalars_stream &output_details);

void SMO_top(dot_product_matrix_stream &dot_product_matrix_outer,
			 dot_product_matrix_stream &dot_product_matrices_inner,
			 training_labels_stream &training_labels_in,
			 training_matrix_stream &training_matrix_outer,
			 training_matrix_stream &training_matrices_inner,
			 input_details_stream &input_details,
			 alphas_stream &alpha_out,
			 indicators_stream &kkt_violations,
			 scalars_stream &output_details);

#endif
