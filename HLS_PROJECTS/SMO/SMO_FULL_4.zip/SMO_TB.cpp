#include "SMO.h"

#include <fstream>
#include <iostream>

#include <string>
using namespace std;

void get_training_details(input_details_AXIS training_details[7]){
	// read training details file and save to 8-length array

	ifstream data_in;
	data_in.open("C:/Users/Ryan/Documents/University/Project/MATLAB/Test Project/smo_test_stimuli/training_details.dat");

	for(int i = 0; i < 4; i++){
		data_in >> training_details[i].data;
		training_details[i].last = 0;
		if(i == 6){
			training_details[i].last = 1;
		}
	}

}

void get_training_dataset(training_matrix_AXIS training_matrix[m][n], training_labels_stream &training_labels_in, int no_training_vectors, int no_variables){
	// read training matrix and labels and save labels to stream
	// training_matrix returned in memory so x_p can be extracted

	ifstream data_matrix;
	data_matrix.open("C:/Users/Ryan/Documents/University/Project/MATLAB/Test Project/smo_test_stimuli/training_matrix.dat");
	ifstream data_labels;
	data_labels.open("C:/Users/Ryan/Documents/University/Project/MATLAB/Test Project/smo_test_stimuli/training_labels.dat");

	for(int i = 0; i < no_training_vectors; i++){
		training_labels_AXIS training_label;
		float label_temp;
		data_labels >> label_temp;
		//data_labels >> training_label.data;
		training_label.data = class_labels(label_temp);
		training_label.last = 0;
		if(i == (no_training_vectors - 1)){
			training_label.last = 1;
		}
		training_labels_in.write(training_label);		// write to stream
		for(int j = 0; j < no_variables; j++){
			data_matrix >> training_matrix[i][j].data;
			training_matrix[i][j].last = 0;
		}
	}

	//training_matrix[no_training_vectors - 1][no_variables - 1].last = 1;

}

void get_dot_product_matrix(dot_product_matrix_AXIS dp_matrix[m][m], int no_training_vectors){
	// read matrix of dot product values from file
	// could compute from training matrix but computationally intesive for the testbench

	ifstream data_dp_matrix;
	data_dp_matrix.open("C:/Users/Ryan/Documents/University/Project/MATLAB/Test Project/smo_test_stimuli/dot_product_matrix.dat");

	for(int i = 0; i < no_training_vectors; i++){
		for(int j = 0; j < no_training_vectors; j++){
			dot_product_matrix_AXIS dp_matrix_val;
			data_dp_matrix >> dp_matrix_val.data;
			dp_matrix_val.last = 0;
			dp_matrix[i][j] = dp_matrix_val;
		}
	}

}

int main(){
	// SMO p loop - testbench
	float tolerance = 0.0001;				// <======= SPECIFY TOLERANCE HERE
	float max_itr = 2;						// <======= SPECIFY MAX_ITR HERE
	float C = 1;

	// GET TRAINING DETAILS
	input_details_AXIS training_parameters[4];
	get_training_details(training_parameters);

	int no_training_vectors = int(training_parameters[0].data);
	int no_variables = int(training_parameters[1].data);

	float no_training_vectors_float = float(no_training_vectors);
	float no_variables_float = float(no_variables);

	input_details_stream input_details;

	// send data set details to stream
	/*for(int i = 0; i < 2; i++){
		input_details.write(training_parameters[i]);
	}*/

	// send max_itr to stream
	input_details_AXIS id_AXIS;
	id_AXIS.data = no_training_vectors_float;
	id_AXIS.last = 0;
	input_details.write(id_AXIS);
	id_AXIS.data = no_variables_float;
	id_AXIS.last = 0;
	input_details.write(id_AXIS);
	id_AXIS.data = max_itr;
	id_AXIS.last = 0;
	input_details.write(id_AXIS);
	id_AXIS.data = tolerance;
	id_AXIS.last = 0;
	input_details.write(id_AXIS);
	id_AXIS.data = C;
	id_AXIS.last = 1;
	input_details.write(id_AXIS);

	// GET DOT PRODUCT MATRIX
	dot_product_matrix_stream dot_product_matrix_inner;
	dot_product_matrix_stream dot_product_matrix_outer;

	dot_product_matrix_AXIS dp_matrix[m][m];
	get_dot_product_matrix(dp_matrix, no_training_vectors);

	// GET TRAINING LABELS AND MATRIX
	training_labels_stream training_labels_in;
	training_matrix_stream training_matrix_outer;
	training_matrix_stream training_matrix_inner;

	static training_matrix_AXIS training_matrix[m][n] = {0};
	get_training_dataset(training_matrix, training_labels_in, no_training_vectors, no_variables);

	// OUTER LOOP REQUIRED FOR MAX_ITR
	for(int g = 0; g < max_itr; g++){
		for(int i = 0; i < no_training_vectors; i++){
			for(int j = 0; j < no_training_vectors; j++){
				dp_matrix[i][j].last = 0;
				if(i == (no_training_vectors - 1) && (j == (no_training_vectors - 1))){
					dp_matrix[i][j].last = 1;
				}
				dot_product_matrix_outer.write(dp_matrix[i][j]);
			}
		}

		// write inner loop dot_product_matrix to streams - NEED OUTER LOOP FOR CONTINOUS STREAMING...
		for(int h = 0; h < no_training_vectors; h++){
			for(int i = 0; i < no_training_vectors; i++){
				for(int j = 0; j < no_training_vectors; j++){
					dp_matrix[i][j].last = 0;
					if(i == (no_training_vectors - 1) && (j == (no_training_vectors - 1)) && (h == (no_training_vectors - 1))){
						dp_matrix[i][j].last = 1;
					}
					dot_product_matrix_inner.write(dp_matrix[i][j]);
				}
			}
		}



		// write to streams - NEED OUTER LOOP FOR CONTINOUS STREAMING...
		for(int i = 0; i < no_training_vectors; i++){
			for(int j = 0; j < no_variables; j++){
				if(i == (no_training_vectors - 1) && (j == (no_variables - 1))){
					training_matrix[i][j].last = 1;
				}
				training_matrix_outer.write(training_matrix[i][j]);
			}
		}

		for(int h = 0; h < no_training_vectors; h++){
			for(int i = 0; i < no_training_vectors; i++){
				for(int j = 0; j < no_variables; j++){
					if(i == (no_training_vectors - 1) && (j == (no_variables - 1)) && (h == (no_training_vectors - 1))){
						training_matrix[i][j].last = 1;
					}
					training_matrix_inner.write(training_matrix[i][j]);
				}
			}
		}

	}

	///////////////////////////
	// TEMPORARY - FOR TESTING
	/*int reqd_itr = 5;
	for(int h = 0; h < reqd_itr; h++){
		for(int i = 0; i < no_training_vectors; i++){
			for(int j = 0; j < no_training_vectors; j++){
				dp_matrix[i][j].last = 0;
				if(i == (no_training_vectors - 1) && (j == (no_training_vectors - 1)) && (h == (reqd_itr - 1))){
					dp_matrix[i][j].last = 1;
				}
				dot_product_matrix_inner.write(dp_matrix[i][j]);
			}
		}
	}

	for(int h = 0; h < reqd_itr; h++){
		for(int i = 0; i < no_training_vectors; i++){
			for(int j = 0; j < no_variables; j++){
				if(i == (no_training_vectors - 1) && (j == (no_variables - 1)) && (h == (reqd_itr - 1))){
					training_matrix[i][j].last = 1;
				}
				training_matrix_inner.write(training_matrix[i][j]);
			}
		}
	}*/
	// TEMPORARY - FOR TESTING
	///////////////////////////

	// DEFINE OUTPUT STREAMS TO BE WRITTEN TO BY DESIGN
	alphas_stream alpha_out;
	scalars_stream output_details;
	indicators_stream kkt_violations;

	// CALL TOP LEVEL FUNCTION
	SMO_top(dot_product_matrix_outer,
			dot_product_matrix_inner,
			training_labels_in,
			training_matrix_outer,
			training_matrix_inner,
			input_details,
			alpha_out,
			kkt_violations,
			output_details);

	// PRINT RESULT TO CONSOLE
	cout << "NEW ALPHA VALUES:\n";
	for(int i = 0; i < no_training_vectors; i++){
		cout << "alpha" << i+1 << " = " << alpha_out.read().data << "\n";
	}

	cout << kkt_violations.read().data << "\n";
	cout << kkt_violations.read().data << "\n";
	cout << kkt_violations.read().data << "\n";
	cout << kkt_violations.read().data << "\n";
	cout << kkt_violations.read().data << "\n";
	cout << kkt_violations.read().data << "\n";
	cout << kkt_violations.read().data << "\n";
	cout << kkt_violations.read().data << "\n";
	cout << kkt_violations.read().data << "\n";
	cout << kkt_violations.read().data << "\n";


	for(int i = 0; i < max_itr; i++){
		output_details.read().data;
	}

	cout << "OFFSET: " << output_details.read().data << "\n";


	//cout << "\nNUMBER OF ITERATIONS: " << output_details.read().data << "\n";

	//cout << "\nOFFSET: " << output_details.read().data << "\n";

	return 0;	// need to check result manually
}
