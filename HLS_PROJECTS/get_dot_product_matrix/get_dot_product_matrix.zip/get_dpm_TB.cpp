#include "get_dpm.h"

#include <fstream>
#include <iostream>

#include <string>
using namespace std;

void get_training_details(input_details_AXIS training_details[7]){
	// read training details file and save to 8-length array

	ifstream data_in;
	data_in.open("C:/Users/Ryan/Documents/University/Project/MATLAB/Test Project/smo_test_stimuli/training_details.dat");

	for(int i = 0; i < 4; i++){
		data_in >> training_details[i].data;
		training_details[i].last = 0;
		if(i == 6){
			training_details[i].last = 1;
		}
	}

}

void get_training_dataset(training_matrix_AXIS training_matrix[m][n], int no_training_vectors, int no_variables){
	// read training matrix and labels and save labels to stream
	// training_matrix returned in memory so x_p can be extracted

	ifstream data_matrix;
	data_matrix.open("C:/Users/Ryan/Documents/University/Project/MATLAB/Test Project/smo_test_stimuli/training_matrix.dat");

	for(int i = 0; i < no_training_vectors; i++){
		for(int j = 0; j < no_variables; j++){
			data_matrix >> training_matrix[i][j].data;
			training_matrix[i][j].last = 0;
		}
	}
	training_matrix[no_training_vectors - 1][no_variables - 1].last = 1;
}

/*dot_products matrix_multiply(training_matrix_AXIS mat_1[m][n], training_matrix_AXIS mat_2[m][n], dot_product_matrix_AXIS res[m][m]){
	// multiply matrices to compare result

}*/

int main(){
	input_details_AXIS training_parameters[4];
	get_training_details(training_parameters);

	n_training_vectors no_training_vectors = training_parameters[0].data;
	n_variables no_variables = training_parameters[1].data;

	int no_training_vectors_int = int(no_training_vectors);
	int no_variables_int = int(no_variables);

	training_matrix_AXIS training_matrix[m][n];
	get_training_dataset(training_matrix, no_training_vectors_int, no_variables_int);

	input_details_stream in_details;
	in_details.write(training_parameters[0]);
	in_details.write(training_parameters[1]);

	// fill training matrix streams
	training_matrix_stream training_mat_stream_1;
	for(int i = 0; i < no_training_vectors_int; i++){
		for(int j = 0; j < no_variables_int; j++){
			training_mat_stream_1.write(training_matrix[i][j]);
		}
	}

	// second stream needs streamed no_training_vectors times
	training_matrix_stream training_mat_stream_2;
	for(int h = 0; h < no_training_vectors_int; h++){
		for(int i = 0; i < no_training_vectors_int; i++){
			for(int j = 0; j < no_variables_int; j++){
				training_mat_stream_2.write(training_matrix[i][j]);
			}
		}
	}

	dot_product_matrix_stream dp_out;

	get_dpm_top(training_mat_stream_1, training_mat_stream_2, dp_out, in_details);

	// print result
	cout << "DOT PRODUCT MATRIX:\n";
	for(int i = 0; i < no_training_vectors_int; i++){
		for(int j = 0; j < no_training_vectors_int; j++){
			dot_product_matrix_AXIS dp_val;
			dp_val = dp_out.read();
			cout << dp_val.data << ", last = " << dp_val.last << "\t";
		}
		cout << "\n";
	}

	return 0;
}
