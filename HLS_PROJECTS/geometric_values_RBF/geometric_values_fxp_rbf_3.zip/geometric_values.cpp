#include "geometric_values.h"

using namespace std;

inter_values kernel_rbf(data_matrix_stream &support_vectors, data_vectors vector_2[n], n_variables *no_variables, coeffs *gamma){
	// computes the result of the radial basis function kernel between two vectors with parameter gamma
	inter_values square_norm = 0;

	// compute the square norm of the difference between the two vectors
	inter_values difference_element = 0;
	square_norm_loop: for(loop_ind_n n1 = 0; n1 < n; n1++){
#pragma HLS PIPELINE
		if(n1 < *no_variables){
			//difference_element = vector_1[n1] - vector_2[n1];
			difference_element = support_vectors.read().data - vector_2[n1];
			square_norm += difference_element * difference_element;
		}
	}

	// compute the kernel function output
	inter_values exp_arg = -*gamma * square_norm;
	inter_values kernel_result = inter_values(exp(exp_arg.to_float()));
	return kernel_result;
}

void get_geometric_values_rbf(data_matrix_stream &support_vectors,
		  	  	  	  	  	  sv_coeffs_stream &sv_coeffs,
							  data_matrix_stream &testing_matrix,
							  coeffs *norm_w,
							  n_svs *no_svs,
							  n_variables *no_variables,
							  n_test_vectors *no_test_vectors,
							  coeffs *gamma,
							  geometric_values_stream &geometric_values_out){

	// this function computes the geometric value for the current testing vector using the radial basis function (RBF) kernel

	coeffs one = 1;
	coeffs norm_w_recip = one / *norm_w;				// so we do not have to compute this division in every iteration of geometric values

	// loop over testing vectors - size of testing matrix
	for(loop_ind_t n1 = 0; n1 < t_max; n1++){
		if(n1 < *no_test_vectors){
			coeffs f_value = 0;

			// get testing vector
			data_vectors testing_vector[n];
			for(loop_ind_n n1_2 = 0; n1_2 < n; n1_2++){
				if(n1_2 < *no_variables){
					testing_vector[n1_2] = testing_matrix.read().data;
				}
			}

			// loop over support vectors
			svs_loop: for(loop_ind_m n2 = 0; n2 < m; n2++){
				if(n2 < *no_svs){
					f_value += sv_coeffs.read().data * kernel_rbf(support_vectors, testing_vector, no_variables, gamma);
				}
				if(n2 == (*no_svs - 1)){
					break;
				}
			}

			// compute the geometric value for this testing vector
			geometric_values_AXIS geometric_value;
			geometric_value.data = (f_value + sv_coeffs.read().data) * norm_w_recip;
			geometric_value.last = 0;
			if(n1 == (*no_test_vectors-1)){
				geometric_value.last = 1;
			}
			geometric_values_out.write(geometric_value);
		}
		if(n1 == (*no_test_vectors-1)){
			break;
		}
	}
}

void geometric_values_rbf_top(data_matrix_stream &support_vectors,
  	  	  	  	  	  	  	  sv_coeffs_stream &sv_coeffs,
							  data_matrix_stream &testing_matrix,
							  dataset_details_stream &classification_details,
							  geometric_values_stream &geometric_values_out){
#pragma HLS INTERFACE axis port=testing_matrix
#pragma HLS INTERFACE axis port=geometric_values_out
#pragma HLS INTERFACE axis port=classification_details
#pragma HLS INTERFACE axis port=support_vectors
#pragma HLS INTERFACE axis port=sv_coeffs
#pragma HLS INTERFACE ap_ctrl_none port=return

	// Note, the offset is the last element in the sv coeffs stream
	// also, the first element is ||w_|| (norm of w)

	// dataset_details stream => no_svs -> no_variables -> no_test_vectors -> gamma
	// sv_coeffs => norm_w -> all coefficients... -> offset

	n_svs no_svs;
	n_variables no_variables;
	n_test_vectors no_test_vectors;
	coeffs gamma;

	gamma = sv_coeffs.read().data;

	// read dataset details stream and store as scalars
	/*no_svs = n_svs(classification_details.read().data);
	no_variables = n_variables(classification_details.read().data);
	no_test_vectors = n_test_vectors(classification_details.read().data);
	gamma = classification_details.read().data;*/

	no_svs = ap_uint<20>(classification_details.read().data);
	no_variables = ap_uint<9>(classification_details.read().data);
	no_test_vectors = ap_uint<20>(classification_details.read().data);

	// get norm of weights vector - required to compute geometric value for the testing vector
	coeffs norm_w = sv_coeffs.read().data;

	// call function to compute geometric values using the default linear kernel
	get_geometric_values_rbf(support_vectors,
			   	   	   	  	 sv_coeffs,
							 testing_matrix,
							 &norm_w,
						  	 &no_svs,
							 &no_variables,
							 &no_test_vectors,
						  	 &gamma,
							 geometric_values_out);

}
