#ifndef GEOMETRIC_VALUES_H__
#define GEOMETRIC_VALUES_H__

#include <fstream>
#include <iostream>
#include <cmath>
#include <ap_fixed.h>
#include <ap_int.h>

#include "hls_stream.h"
#include <ap_axi_sdata.h>

#define m 1000000	// (per training model) - maximum number of possible training vectors in the dataset (and hence max no of support vectors)
#define n 256		// maximum number of possible variables in the dataset
#define t_max 1000000				// maximum number of testing vectors in dataset

// type definitions
//typedef float data_vectors;
typedef ap_fixed<16,1> data_vectors;	// 1 bit for integer component - only work for hs datasets
//typedef float coeffs;
typedef ap_fixed<32,12> coeffs;			// 8 bits for integer component - max value for C is 127
//typedef int n_svs;
//typedef int n_variables;
typedef int n_classes;
//typedef int n_test_vectors;
typedef int data_labels;

typedef ap_uint<20> n_svs;				// max 1 million support vectors
typedef ap_uint<9> n_variables;			// max 256 variables
typedef ap_uint<20> n_test_vectors;		// max 1 million testing vectors

//typedef float offsets;
typedef ap_fixed<32,8> offsets;

//typedef int loop_ind;
typedef ap_uint<20> loop_ind_m;			// loop over support vectors
typedef ap_uint<9> loop_ind_n;			// loop over variables - only increment from zero to 255
typedef ap_uint<20> loop_ind_t;			// loop over testing vectors

//typedef int ds_details;
typedef ap_uint<32> ds_details;			// any dataset detail cannot exceed integer 2^(32)-1

typedef ap_fixed<32,12> inter_values;	// 12 bits for integer component - in 256 dimensional feature-space, geometric values may not exceed 32
//typedef float inter_values;
//typedef int test_vec_indices;
//typedef int sv_indices;
typedef float kernel_param;
//typedef ap_fixed<48,24> kernel_param;

// structs contain the sideband signal TLAST which must be set when the stream has completed
/*struct support_vectors_AXIS{
	data_vectors data;
	bool last;
};

struct testing_matrix_AXIS{
	data_vectors data;
	bool last;
};*/

struct data_matrices_AXIS{
	data_vectors data;
	bool last;
};

struct sv_coeffs_AXIS{
	coeffs data;
	bool last;
};

struct dataset_details_AXIS{
	ds_details data;
	bool last;
};

// output AXI stream - geometric values
struct geometric_values_AXIS{
	inter_values data;
	bool last;
};

// the following type is used for the axi streams - hls_stream facilitates correct use of the stream in the c++ code
//typedef hls::stream<support_vectors_AXIS> support_vectors_stream;
//typedef hls::stream<testing_matrix_AXIS> testing_matrix_stream;
typedef hls::stream<data_matrices_AXIS> data_matrix_stream;			// for support vectors and testing matrix
typedef hls::stream<sv_coeffs_AXIS> sv_coeffs_stream;
typedef hls::stream<dataset_details_AXIS> dataset_details_stream;
typedef hls::stream<geometric_values_AXIS> geometric_values_stream;

coeffs get_w(data_matrix_stream &data_matrices,
			 sv_coeffs_stream &sv_coeffs,
			 n_svs *no_svs,
			 n_variables *no_variables,
			 coeffs w[n]);

void get_geometric_values_linear(data_matrix_stream &data_matrices,
								 sv_coeffs_stream &sv_coeffs,
								 n_svs *no_svs,
								 n_variables *no_variables,
								 n_test_vectors *no_test_vectors,
								 geometric_values_stream &geometric_values);

void geometric_values_top(data_matrix_stream &data_matrices,
						  sv_coeffs_stream &sv_coeffs,
						  dataset_details_stream &dataset_details,
						  geometric_values_stream &geometric_values);

#endif
