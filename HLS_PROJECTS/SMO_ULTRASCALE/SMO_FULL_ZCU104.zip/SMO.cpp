#include "SMO.h"

dot_products dot_product(data_vectors row_vec[n], data_vectors col_vec[n], n_variables *no_variables){

	// return the dot product between two input vectors

	dot_products accumulate = 0.0;

	dot_product_accum: for(loop_ind_n n1 = 0; n1 < n; n1++){
#pragma HLS PIPELINE
		if(n1 < *no_variables){
			accumulate = accumulate + row_vec[n1] * col_vec[n1];
		}
		else{
			break;
		}
	}

	return accumulate;

}

void get_training_vector(training_matrix_stream &training_matrix,
						 data_vectors x_q[n],
						 n_variables *no_variables){

	// return training vector at index q - correct streaming of training matrix is ensured in calling function
	get_training_vector_loop: for(loop_ind_n n1 = 0; n1 < n; n1++){
		if(n1 < *no_variables){
			x_q[n1] = training_matrix.read().data;
		}
		else{
			break;
		}
	}

}

inter_values get_u_k(dot_product_matrix_stream &dot_product_matrix,
		   	 class_labels y[m],
			 alphas_AXIS alpha[m],
			 n_training_vectors *no_training_vectors,
			 n_variables *no_variables,
			 training_details *offset){

	// compute the value of u_k - functional value of data vector x_k - indicates which side of current hyperplane (defined by alpha and b) the point x_k
	// is on and how far it is from the hyperplane relative to the support vectors being a functional margin of one from the hyperplane

	inter_values accumulator = 0.0;

	u_k_accum: for(loop_ind_m n1 = 0; n1 < m; n1++){
#pragma HLS PIPELINE
		if(n1 < *no_training_vectors){
			// each read of the dot product matrix stream is the next element in the dot product vector - length of vector is no_training_vectors
			accumulator += alpha[n1].data * y[n1] * dot_product_matrix.read().data;
		}
		else{
			break;
		}
	}

	// return functional value for x_k
	return accumulator + *offset;
}

void SMO_p_loop_linear(dot_product_matrix_stream &dot_product_matrix,
					   training_matrix_stream &training_matrix,
					   data_vectors x_p[n],
					   class_labels y[m],
					   alphas_AXIS alpha[m],
					   n_training_vectors *no_training_vectors,
					   n_variables *no_variables,
					   training_details *C,
					   training_details *tolerance,
					   training_details *offset,
					   inter_values *E_p,
					   training_data_indices *p_in,
					   n_training_vectors *changed_alphas){

	// return the updated lagrange multipliers (alpha) for some p value

	training_data_indices p = *p_in - 1;		// only used for indexing - subtract one
	training_details offset_temp = *offset;
	training_details changed_alphas_temp = *changed_alphas;

	// compute and store for use in each iteration
	dot_products xp_xp = dot_product(x_p, x_p, no_variables);

	// loop over alpha_q values - this will happen if KKT violation with alpha_p (decided in processing system)
	SMO_q_loop:for(loop_ind_m q = 0; q < m; q++){
		if(q < *no_training_vectors){
			if(q == p){
				// also need to read one of the vectors of dot product values at index p
				for(loop_ind_m n1 = 0; n1 < m; n1++){
					if(n1 < *no_training_vectors){
						dot_product_matrix.read();
					}
					else{
						break;
					}
				}
				// still need to read the vector at index p of the dot product matrix to ensure true streaming
				for(loop_ind_n n1 = 0; n1 < n; n1++){
					if(n1 < *no_variables){
						training_matrix.read();			// read, dont store in memory
					}
					else{
						break;
					}
				}
			}
			else{
				// get u_q
				inter_values u_q = 0;
				u_q = get_u_k(dot_product_matrix, y, alpha, no_training_vectors, no_variables, &offset_temp);

				// get E_q - error term - indicates error between label and functional value
				inter_values E_q = 0;
				E_q = u_q - y[q];

				// get old (current) version of both alpha values
				alphas alpha_p_old = alpha[p].data;
				alphas alpha_q_old = alpha[q].data;

				// compute s - either 1 or -1
				class_labels s = y[p] * y[q];

				// check if s = 1, else s = -1 => s = y_p * y_q
                // compute upper and lower bounds for alpha_q_new
				alphas L = 0;
				alphas H = 0;
				if(s == 1){
					// classes for x_p and x_q are same
					if((alpha_p_old + alpha_q_old - *C) > 0){
						L = alpha_p_old + alpha_q_old - *C;
					}
					else{
						L = 0;
					}
					if((alpha_p_old + alpha_q_old) < *C){
						H = alpha_p_old + alpha_q_old;
					}
					else{
						H = *C;
					}
				}
				else{
					// s =/= 1 - classes are not the same
					if((alpha_q_old - alpha_p_old) > 0){
						L = alpha_q_old - alpha_p_old;
					}
					else{
						L = 0;
					}
					if((*C + alpha_q_old - alpha_p_old) < *C){
						H = *C + alpha_q_old - alpha_p_old;
					}
					else{
						H = *C;
					}
				}

				// check if L and H are equal
				if((H - *tolerance) < L){
					// need to read training matrix, index q - since continuing past read below
					for(loop_ind_n n1 = 0; n1 < n; n1++){
						if(n1 < *no_variables){
							training_matrix.read();
						}
					}
					continue;
				}

				// compute eta - kernel product here for kernelised SVM - this version linear so kernel function is dot product
				inter_values eta = 0;
				// get x_q
				data_vectors x_q[n];
				get_training_vector(training_matrix, x_q, no_variables);
				dot_products xp_xq = dot_product(x_p, x_q, no_variables);
				dot_products xq_xq = dot_product(x_q, x_q, no_variables);

				//eta = 2 * dot_product(x_p, x_q) - dot_product(x_p, x_p) - dot_product(x_q, x_q);
				eta = 2 * xp_xq - xp_xp - xq_xq;

				// compute the new value of alpha_q - used to calculate new alpha_p
				alphas alpha_q_new = alpha_q_old + y[q] * (E_q - *E_p) / eta;

				// we need to consider the original wolfe dual constraint (lagrange multipliers must be in range [0,C] - (inclusive of ends)
				if(alpha_q_new >= H){
					alpha_q_new = H;
				}
				else if(alpha_q_new <= L){
					alpha_q_new = L;
				}
				// (else stays the same - constraint satisfied)

				// if alpha_q_new same as alpha_q_old - no need to update alpha_p_new
				alphas alpha_p_new = alpha_p_old;

				// update alphas vector
				alpha[p].data = alpha_p_new;
				alpha[q].data = alpha_q_new;

				// only need to compute new alpha_p if change in alpha_q
				/*if(abs(alpha_q_new - alpha_q_old) < *tolerance){
					continue;
				}*/
				alphas delta_q = alpha_q_new - alpha_q_old;
				if((delta_q <= 0) && (delta_q > (0 - *tolerance))){
					continue;
				}
				else if((delta_q >= 0) && (delta_q < *tolerance)){
					continue;
				}
				// else continue

				// update alpha_p
				alpha_p_new = alpha_p_old - s * (alpha_q_new - alpha_q_old);

				// we need to update the weights vector and BIAS(OFFSET); the weights vector is implicitly updated by changing alpha_p and alpha_q
				alphas delta_p = alpha_p_new - alpha_p_old;
				//alphas delta_q = alpha_q_new - alpha_q_old;

				dot_products xq_xp = dot_product(x_q, x_p, no_variables);
				training_details b_p_new = offset_temp - *E_p - delta_p * y[p] * xp_xp - delta_q * y[q] * xq_xp;
				training_details b_q_new = offset_temp - E_q - delta_p * y[p] * xp_xq - delta_q * y[q] * xq_xq;
				//we use this if one of alpha_p_new or alpha_q_new correspond to a support vector => 0 < alpha_k_new < C

				if((alpha_p_new > 0) && (alpha_p_new < *C)){
					offset_temp = b_p_new;
				}
				else if((alpha_q_new > 0) && (alpha_q_new < *C)){
					offset_temp = b_q_new;
				}
				else{
					offset_temp = (b_p_new + b_q_new) / 2;
				}

				alpha[p].data = alpha_p_new;					// update alphas vector

				changed_alphas_temp = changed_alphas_temp + 1;	// updated an alpha value
			}
		}
		else{
			break;
		}
	}

	*offset = offset_temp;
	*changed_alphas = changed_alphas_temp;
}

void SMO_outer(dot_product_matrix_stream &dot_product_matrix_outer,
		 	   dot_product_matrix_stream &dot_product_matrices_inner,
			   class_labels y[m],
			   training_matrix_stream &training_matrix_outer,
			   training_matrix_stream &training_matrices_inner,
			   alphas_AXIS alpha[m],
			   n_training_vectors *no_training_vectors,
			   n_variables *no_variables,
			   training_details *C,
			   training_details *tolerance,
			   n_max_itr *max_itr_user,
			   indicators_stream &kkt_violations,
			   scalars_stream &output_details){
// this function iterates over the p values, calling the inner loop function (all of the q loops) as needed
// also, it iterates some maximum number of times as specified by the user in the "max_itr_user" parameter

	n_training_vectors changed_alphas = 0;

	training_details no_itr;
	training_details offset;

	no_itr = 0;
	offset = 0;

	max_itr_loop: for(loop_ind_itr n1 = 0; n1 < max_itr_abs; n1++){
		if(n1 < *max_itr_user){
			changed_alphas = 0;

			// loop over all p values
			smo_p_loop: for(loop_ind_m p = 0; p < m; p++){
				if(p < *no_training_vectors){
					class_labels y_p = y[p];

					// get u_p
					inter_values u_p = get_u_k(dot_product_matrix_outer, y, alpha, no_training_vectors, no_variables, &offset);

					// compute the error term for training vector x_p, E_p
					inter_values E_p = u_p - y_p;

					// get alpha_p_old
					alphas alpha_p_old = alpha[p].data;

					inter_values yp_Ep = y_p * E_p;

					// get x_p
					data_vectors x_p[n];
					get_training_vector(training_matrix_outer, x_p, no_variables);

					// check for KKT violation - need two if statements as the second one wil not be entered unless the inner matrices are made
					// available on the mm2s (memory-map to stream)
					//bool kkt_check = (alpha_p_old < *C && yp_Ep < -*tolerance) || (alpha_p_old > 0 && yp_Ep > *tolerance);
					if((alpha_p_old < *C && yp_Ep < -*tolerance) || (alpha_p_old > 0 && yp_Ep > *tolerance)){
						// indicate to the processing system, a KKY violation has taken place and the inner matrices should be transferred
						indicators_AXIS kkt_viol_AXIS;
						kkt_viol_AXIS.data = 1;
						kkt_viol_AXIS.last = 1;
						kkt_violations.write(kkt_viol_AXIS);
					}
					if((alpha_p_old < *C && yp_Ep < -*tolerance) || (alpha_p_old > 0 && yp_Ep > *tolerance)){
						// call function to iterate over all q loops
						training_data_indices p_in = p + 1;
						SMO_p_loop_linear(dot_product_matrices_inner,
										  training_matrices_inner,
										  x_p,
										  y,
										  alpha,
										  no_training_vectors,
										  no_variables,
										  C,
										  tolerance,
										  &offset,
										  &E_p,
										  &p_in,
										  &changed_alphas);
					}
					else{
						// indicate to processing system when there is no KKT violation
						indicators_AXIS kkt_viol_AXIS;
						kkt_viol_AXIS.data = 2;
						kkt_viol_AXIS.last = 1;
						kkt_violations.write(kkt_viol_AXIS);
					}
					// FOR TESTING...
					// in actual design we will simply not load enough inner training matrices and dot product matrices to break the DMA transfer
					// i.e. only the correct amount for data will be passed to dma
					/*else{
						// read the inner training matrix
						for(loop_ind i = 0; i < m; i++){
							if(i < *no_training_vectors){
								for(loop_ind j = 0; j < n; j++){
									if(j < *no_variables){
										training_matrices_inner.read();
									}
								}
							}
						}
						// read the inner dot product matrix
						for(loop_ind i = 0; i < m; i++){
							if(i < *no_training_vectors){
								for(loop_ind j = 0; j < m; j++){
									if(j < *no_training_vectors){
										dot_product_matrices_inner.read();
									}
								}
							}
						}
					}*/
					// FOR TESTING...
				}
				else{
					break;
				}
			}

			// in this case, we do not need to do any more SMO iterations
			if(changed_alphas == 0){
				break;
			}

			no_itr = no_itr + 1;

			// send indication to PS that we should go to next iteration
			scalars_AXIS no_itr_AXIS;
			no_itr_AXIS.data = no_itr;
			no_itr_AXIS.last = 1;
			output_details.write(no_itr_AXIS);

		}
		else{
			break;
		}
	}

	scalars_AXIS offset_AXIS;
	offset_AXIS.data = offset;
	offset_AXIS.last = 1;
	output_details.write(offset_AXIS);

}

void SMO_top(dot_product_matrix_stream &dot_product_matrix_outer,
			 dot_product_matrix_stream &dot_product_matrices_inner,
			 training_labels_stream &training_labels_in,
			 training_matrix_stream &training_matrix_outer,
			 training_matrix_stream &training_matrices_inner,
			 input_details_stream &input_details,
			 alphas_stream &alpha_out,
			 indicators_stream &kkt_violations,
			 scalars_stream &output_details){
#pragma HLS INTERFACE axis port=kkt_violations
#pragma HLS INTERFACE ap_ctrl_none port=return
#pragma HLS INTERFACE axis port=dot_product_matrix_outer
#pragma HLS INTERFACE axis port=dot_product_matrices_inner
#pragma HLS INTERFACE axis port=training_labels_in
#pragma HLS INTERFACE axis port=training_matrix_outer
#pragma HLS INTERFACE axis port=training_matrices_inner
#pragma HLS INTERFACE axis port=input_details
#pragma HLS INTERFACE axis port=alpha_out
#pragma HLS INTERFACE axis port=output_details

	// get various scalar parameters from input details stream - unsigned integers
	n_training_vectors no_training_vectors = ap_uint<16>(input_details.read().data);
	n_variables no_variables = ap_uint<9>(input_details.read().data);
	n_max_itr max_itr = ap_uint<8>(input_details.read().data);
	training_details tolerance = ap_fixed<32,12>(input_details.read().data);
	training_details C = ap_fixed<32,12>(input_details.read().data);

	// store training labels
	class_labels y[m];
//#pragma HLS RESOURCE variable=y core=RAM_2P_BRAM
	for(loop_ind_m n1 = 0; n1 < m; n1++){
		if(n1 < no_training_vectors){
			y[n1] = ap_int<2>(training_labels_in.read().data);
		}
		else{
			break;
		}
	}

	// store alpha values
	alphas_AXIS alpha[m];
//#pragma HLS RESOURCE variable=alpha core=RAM_2P_BRAM
	for(loop_ind_m n1 = 0; n1 < m; n1++){
		if(n1 < no_training_vectors){
			alpha[n1].data = 0;
			alpha[n1].last = 0;
		}
		else{
			break;
		}
	}
	alpha[no_training_vectors - 1].last = 1;

	training_details no_itr = 0;
	training_details offset = 0;

	// call next function
	SMO_outer(dot_product_matrix_outer,
			  dot_product_matrices_inner,
			  y,
			  training_matrix_outer,
			  training_matrices_inner,
			  alpha,
			  &no_training_vectors,
			  &no_variables,
			  &C,
			  &tolerance,
			  &max_itr,
			  kkt_violations,
			  output_details);

	// output resulting alpha values and new offset/changed alphas to streams
	/*scalars_AXIS offset_AXIS;
	offset_AXIS.data = offset;
	offset_AXIS.last = 0;
	output_details.write(offset_AXIS);

	scalars_AXIS no_itr_AXIS;
	no_itr_AXIS.data = no_itr;
	no_itr_AXIS.last = 1;
	output_details.write(no_itr_AXIS);*/

	// output alpha stream
	for(loop_ind_m n1 = 0; n1 < m; n1++){
		if(n1 < no_training_vectors){
			alpha_out.write(alpha[n1]);
		}
		else{
			break;
		}
	}

}
