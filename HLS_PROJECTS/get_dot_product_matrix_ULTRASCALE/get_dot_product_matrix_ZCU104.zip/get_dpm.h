#ifndef GET_DPM_H__
#define GET_DPM_H__

#include <cmath>
#include <math.h>
#include <ap_fixed.h>
#include <ap_int.h>

#include "hls_stream.h"
#include <ap_axi_sdata.h>

#define m 20000	// maximum number of possible training vectors in the dataset
#define n 256		// maximum number of possible variables in the dataset

typedef ap_uint<16> n_training_vectors;		// maximum of 65535 training vectors (per binary classifier)
typedef ap_uint<9> n_variables;				// max 256 variables
typedef ap_uint<16> loop_ind_m;			// loop over training vectors
typedef ap_uint<9> loop_ind_n;			// loop over variables - only increment from zero to 255

typedef ap_fixed<16,1> data_vectors;	// 1 bit for integer component - only work for hs datasets
typedef ap_fixed<32,12> dot_products;

// structs contain the sideband signal TLAST which must be set when the stream has completed
struct dot_product_matrix_AXIS{
	dot_products data;
	bool last;
};

struct training_matrix_AXIS{
	data_vectors data;
	bool last;
};

struct input_details_AXIS{
	ap_uint<16> data;
	bool last;
};

// HLS stream types
typedef hls::stream<dot_product_matrix_AXIS> dot_product_matrix_stream;
typedef hls::stream<training_matrix_AXIS> training_matrix_stream;
typedef hls::stream<input_details_AXIS> input_details_stream;

dot_products get_dot_product(data_vectors row_vec[m], training_matrix_stream &col_vec, n_variables *no_variables);

void get_dpm_top(training_matrix_stream &training_matrix,
				 training_matrix_stream &training_matrix_transpose,
				 dot_product_matrix_stream &dot_product_matrix_out,
				 input_details_stream &input_details);

#endif
