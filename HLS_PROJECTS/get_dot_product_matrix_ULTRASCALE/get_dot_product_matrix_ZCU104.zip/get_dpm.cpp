#include "get_dpm.h"

dot_products get_dot_product(data_vectors row_vec[n], training_matrix_stream &col_vec, n_variables *no_variables){
	// compute dot product between row vector stored in memory and column vector streamed
	dot_products accumulator = 0;

	dp_loop: for(loop_ind_n n1 = 0; n1 < n; n1++){
#pragma HLS PIPELINE
		if(n1 < *no_variables){
			accumulator = accumulator + row_vec[n1] * col_vec.read().data;
		}
		else{
			break;
		}
	}

	return accumulator;
}

void get_dpm_top(training_matrix_stream &training_matrix,
				 training_matrix_stream &training_matrix_transpose,
				 dot_product_matrix_stream &dot_product_matrix_out,
				 input_details_stream &input_details){
#pragma HLS INTERFACE ap_ctrl_none port=return
#pragma HLS INTERFACE axis port=input_details
#pragma HLS INTERFACE axis both port=dot_product_matrix_out
#pragma HLS INTERFACE axis port=training_matrix_transpose
#pragma HLS INTERFACE axis both port=training_matrix
	// returns the matrix multiplication between a data matrix and its transpose
	// note: this is NOT the covariance of the dataset: i.e. if training matrix A is
	// 100k x 256 (100k observations by 256 variables) then the result is A.A^T (100k by 100k)

	// also note: the second data matrix is not transposed in terms of the order of the elements
	// in standard c multi-dimensional array ordering - this is to allow the matrix multiplication to
	// be computed in a streaming fashion

	n_training_vectors no_training_vectors = ap_uint<16>(input_details.read().data);
	n_variables no_variables = ap_uint<9>(input_details.read().data);

	data_vectors first_mat_row[n];

	// loop over rows of first data matrix
	first_rows: for(loop_ind_m n1 = 0; n1 < m; n1++){
		if(n1 < no_training_vectors){

			// get row of first matrix (length no_variables) and store in memory
			get_row: for(loop_ind_n n1_1 = 0; n1_1 < n; n1_1++){
				if(n1_1 < no_variables){
					first_mat_row[n1_1] = training_matrix.read().data;
				}
				else{
					break;
				}
			}

			dot_product_matrix_AXIS result;

			// loop over 'columns' of second matrix
			second_columns: for(loop_ind_m n2 = 0; n2 < m; n2++){
				if(n2 < no_training_vectors){
					if(n2 < (no_training_vectors-1)){		// up to second last iteration of second columns
						result.data = get_dot_product(first_mat_row, training_matrix_transpose, &no_variables);
						result.last = 0;
						dot_product_matrix_out.write(result);
					}
					else if(n1 == (no_training_vectors-1)){						// last iteration of second columns AND last iteration of first rows - i.e. end of operations
						result.data = get_dot_product(first_mat_row, training_matrix_transpose, &no_variables);
						result.last = 1;
						dot_product_matrix_out.write(result);
						break;
					}
					else{		// last iteration of second columns but NOT first rows - keep iterating outer loop
						result.data = get_dot_product(first_mat_row, training_matrix_transpose, &no_variables);
						result.last = 0;
						dot_product_matrix_out.write(result);
					}
				}
				else{
					break;
				}
			}
		}
		else{
			break;
		}
	}

}
